---
name: Autonomous Kinetic Dark
colors:
  surface: '#121316'
  surface-dim: '#121316'
  surface-bright: '#38393c'
  surface-container-lowest: '#0d0e11'
  surface-container-low: '#1b1b1f'
  surface-container: '#1f1f23'
  surface-container-high: '#292a2d'
  surface-container-highest: '#343538'
  on-surface: '#e3e2e6'
  on-surface-variant: '#e0c0b2'
  inverse-surface: '#e3e2e6'
  inverse-on-surface: '#2f3034'
  outline: '#a88a7f'
  outline-variant: '#594238'
  surface-tint: '#ffb595'
  primary: '#ffb595'
  on-primary: '#581e00'
  primary-container: '#f36b21'
  on-primary-container: '#521c00'
  inverse-primary: '#a23f00'
  secondary: '#ffbf81'
  on-secondary: '#4a2800'
  secondary-container: '#ff9800'
  on-secondary-container: '#653900'
  tertiary: '#4ae176'
  on-tertiary: '#003915'
  tertiary-container: '#00ab4d'
  on-tertiary-container: '#003513'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdbcd'
  primary-fixed-dim: '#ffb595'
  on-primary-fixed: '#360f00'
  on-primary-fixed-variant: '#7c2e00'
  secondary-fixed: '#ffdcbe'
  secondary-fixed-dim: '#ffb870'
  on-secondary-fixed: '#2c1600'
  on-secondary-fixed-variant: '#693c00'
  tertiary-fixed: '#6bff8f'
  tertiary-fixed-dim: '#4ae176'
  on-tertiary-fixed: '#002109'
  on-tertiary-fixed-variant: '#005321'
  background: '#121316'
  on-background: '#e3e2e6'
  surface-variant: '#343538'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 34px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.01em
  title-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.06em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.875rem
  space-lg: 1.25rem
  space-xl: 1.75rem
---

## Brand & Style

This design system delivers a focused, stealth-grade visual experience tailored for an autonomous Android mobile agent and computer-use operating surface. The brand evokes uncompromising precision, executive-level technical sophistication, and calm authority. It avoids gimmicks, playful illustrations, or casual chat semantics, framing the AI not as a playful novelty chatbot, but as an invisible, highly capable digital operator executing real actions across device layers.

The visual style blends modern technical minimalism with subtle dark glassmorphism and surgical border highlights. It employs obsidian charcoal planes, razor-thin structural borders, precise monochrome line iconography, and a hyper-deliberate vivid deep orange and warm amber kinetic glow that activates only during active reasoning, system permissions, and live device interventions.

## Colors

The palette is engineered exclusively for high-clarity OLED dark modes to minimize eye fatigue during sustained technical operation. 

### Canvas and Surfaces
- **Canvas Base**: `#101114` (Deep Charcoal Canvas)
- **Container Secondary**: `#181A1F` (Card and grouped module background)
- **Elevated Surface / Overlays**: `#20232A` (Bottom sheets, elevated modals, dialogs)
- **Structural Stroke / Hairlines**: `#2A2E37` (Base containment, dividers, segmented pill borders)
- **Highlight Stroke**: `rgba(243, 107, 33, 0.35)` (Active focus state and autonomous execution ring)

### Accents & Semantic Signals
- **Primary Kinetic Accent**: `#F36B21` (High-octane deep orange for primary actions, active autonomy rings, primary execution triggers)
- **Secondary Warm Glow**: `#FF9800` (Subtle amber for processing states, warnings, and permission inspection)
- **Success / Connected State**: `#22C55E` (Ready state, permission allowed)
- **Halted / Offline State**: `#EF4444` (Critical stop, paused, rejected action)

### Typography & Icon Tones
- **Text High Emphasis**: `#F5F5F5`
- **Text Medium Emphasis**: `#A0A3AA`
- **Text Low / Muted**: `#5E626E`

## Typography

The typography strategy leverages **Inter** across all UI layers for supreme legibility at small sizes, fast scanning speeds, and modern technical utility. 

- **Section Headers and Meta Tags**: Use `label-sm` with uppercase styling and letter-spacing (`+0.06em`) in `#A0A3AA` to create clear groupings without adding visual bulk.
- **Agent Prompts and Headings**: Rendered using `headline-md` and `headline-lg` in `#F5F5F5` with tight negative tracking to maintain punch and executive tone.
- **Technical Logs and Execution Traces**: Set in `body-sm` using `#A0A3AA` on secondary containers to keep background operations readable yet unobtrusive.

## Layout & Spacing

The layout model is optimized primarily for one-handed thumb interaction within handheld Android viewports, expanding seamlessly into split sheets on tablet form factors.

- **Grid Model**: A fluid 4-column layout on mobile devices (`<600px`) transitioning to 8 columns on tablets. Fixed lateral margin is set to `1rem` (16px) to maximize horizontal real estate on edge-to-edge mobile screens.
- **Rhythm**: Spacing follows a 4px/8px modular base. Tight pairings between related items (like an icon and its label) use `space-xs` (4px) or `space-sm` (8px). Container inner padding defaults to `space-md` (14px) or `space-lg` (20px).
- **Safe Area Insets**: Floating action pill bars and bottom navigation components stay strictly aware of Android gesture navigation bars by anchoring `1.5rem` above system insets.

## Elevation & Depth

Visual hierarchy uses tonal surface layering combined with razor-thin structural borders and restrained frosted backdrops. Rather than muddy diffuse drop shadows, elevation is achieved via luminance graduation and border definition:

- **Surface Level 0 (Base Canvas)**: `#101114` — Flat, non-interactive ground.
- **Surface Level 1 (Cards, Modules, Groups)**: `#181A1F` background framed by a `1px` solid outline of `#2A2E37`.
- **Surface Level 2 (Floating Trays, Bottom Sheets, Top Bars)**: `#20232A` at 85% opacity with a `16px` backdrop-filter blur (`blur(16px)`).
- **Focused Execution Depth**: For active autonomous tasks, cards apply an inner highlight gradient alongside an ambient accent glow: `box-shadow: 0 8px 32px -4px rgba(243, 107, 33, 0.15)`.

## Shapes

The design language establishes a curved, ergonomic geometry that balances mobile thumb comfort with crisp hardware-inspired precision.

- **Primary Cards & Containers**: Use `rounded-lg` (16px to 18px), matching contemporary flagship mobile display corners.
- **Execution Modules & Modals**: Use `rounded-xl` (20px to 24px) to create soft containment for rich multimodal controls.
- **Interactive Pills, Badges & Model Switchers**: Completely pill-shaped (`9999px`), ensuring immediate tactile recognition as tappable interactive states.

## Components

### 1. Autonomous Execution Cards
- Encased in `#181A1F` with a continuous `1px` border of `#2A2E37`. When an agent workflow is active, the border shifts to `rgba(243, 107, 33, 0.6)` with an ambient orange rim glow.
- Includes a live step indicator, small progress status row, and an immediate high-contrast "Pause" or "Take Over" pill button.

### 2. Status Badges
- Compact pill geometries (`height: 24px`, horizontal padding: `8px`) with a `6px` status pulse dot:
  - **Ready**: Dot `#22C55E`, background `rgba(34, 197, 94, 0.1)`, text `#22C55E`.
  - **Working / Running**: Dot `#F36B21` (with subtle ping animation), background `rgba(243, 107, 33, 0.12)`, text `#F36B21`.
  - **Paused**: Dot `#FF9800`, background `rgba(255, 152, 0, 0.12)`, text `#FF9800`.
  - **Offline**: Dot `#5E626E`, background `rgba(94, 98, 110, 0.15)`, text `#A0A3AA`.

### 3. Model Switcher Pill
- Positioned in the header or active console. Floating pill with `background: #181A1F`, border `#2A2E37`, containing the model indicator, an engine status glyph, and an arrow chevron. Tapping opens an elevated modal in `#20232A`.

### 4. Permission Chips & Grouped List Rows
- Inset grouping layout: rows grouped inside a parent container `#181A1F` with `1px` dividers (`#2A2E37`).
- Each permission row includes a thin monochrome line icon (`stroke-width: 1.75`), label in `#F5F5F5`, and an trailing state badge or clean custom switch toggle.

### 5. Buttons & Triggers
- **Primary Button**: Solid vivid deep orange (`#F36B21`), text `#101114` or pure white (`#FFFFFF`) with `font-weight: 600`. Rounded corners at 14px.
- **Secondary / Ghost Button**: Background `#20232A`, border `1px solid #2A2E37`, text `#F5F5F5`.
- **Destructive Button**: Background `rgba(239, 68, 68, 0.1)`, border `1px solid rgba(239, 68, 68, 0.25)`, text `#EF4444`.

### 6. Interactive Input Dock
- Floating at the bottom above system gestures. Dark frosted background (`rgba(24, 26, 31, 0.88)` with `backdrop-filter: blur(20px)`), enclosing quick-action triggers, voice pulse button, and minimalist attachment pins.